==========Ex02 Checking Report==========
Exercise No...........: 02
First Student Details.: 305070831 - Ohad Slutzky
Second Student Details: 204381487 - Tomer Guttman
Delivery Date.........: 18 - May - 2019
Delivered In Delay....: No
Delay Reason..........: 
Visual Studio Version.: 2015
Comments..............: 1.Best played in console screen at full size.
						2.When it is PC's turn there is a delay to imitate 'thinking' by the computer.			
==========End Ex02 Checking Report==========