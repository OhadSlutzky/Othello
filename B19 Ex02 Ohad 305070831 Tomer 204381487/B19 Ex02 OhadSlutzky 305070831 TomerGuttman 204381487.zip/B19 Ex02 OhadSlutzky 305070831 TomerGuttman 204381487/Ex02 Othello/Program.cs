﻿using System;

namespace Ex02_Othello
{
    public class Program
    {
        public static void Main()
        {
            Othello.Othello.Run();
        }
    }
}
